--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Vinoteque";
--
-- Name: Vinoteque; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Vinoteque" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Italian_Italy.1252';


ALTER DATABASE "Vinoteque" OWNER TO postgres;

\connect "Vinoteque"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cantina; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cantina (
    id integer NOT NULL,
    nome character varying NOT NULL,
    cantina_indirizzo integer NOT NULL,
    descrizione text NOT NULL
);


ALTER TABLE public.cantina OWNER TO postgres;

--
-- Name: cantina_cantina_indirizzo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cantina_cantina_indirizzo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cantina_cantina_indirizzo_seq OWNER TO postgres;

--
-- Name: cantina_cantina_indirizzo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cantina_cantina_indirizzo_seq OWNED BY public.cantina.cantina_indirizzo;


--
-- Name: cantina_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cantina_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cantina_id_seq OWNER TO postgres;

--
-- Name: cantina_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cantina_id_seq OWNED BY public.cantina.id;


--
-- Name: carrello; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carrello (
    id integer NOT NULL,
    carrello_vino integer NOT NULL,
    carrello_utente integer NOT NULL
);


ALTER TABLE public.carrello OWNER TO postgres;

--
-- Name: carrello_carrello_utente_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.carrello_carrello_utente_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.carrello_carrello_utente_seq OWNER TO postgres;

--
-- Name: carrello_carrello_utente_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.carrello_carrello_utente_seq OWNED BY public.carrello.carrello_utente;


--
-- Name: carrello_carrello_vino_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.carrello_carrello_vino_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.carrello_carrello_vino_seq OWNER TO postgres;

--
-- Name: carrello_carrello_vino_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.carrello_carrello_vino_seq OWNED BY public.carrello.carrello_vino;


--
-- Name: carrello_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.carrello_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.carrello_id_seq OWNER TO postgres;

--
-- Name: carrello_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.carrello_id_seq OWNED BY public.carrello.id;


--
-- Name: indirizzo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.indirizzo (
    id integer NOT NULL,
    via character varying NOT NULL,
    numero_civico character varying NOT NULL,
    citta character varying NOT NULL,
    cap character(5) NOT NULL,
    regione character varying NOT NULL,
    nazione character varying NOT NULL
);


ALTER TABLE public.indirizzo OWNER TO postgres;

--
-- Name: indirizzo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.indirizzo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.indirizzo_id_seq OWNER TO postgres;

--
-- Name: indirizzo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.indirizzo_id_seq OWNED BY public.indirizzo.id;


--
-- Name: metodo_pagamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.metodo_pagamento (
    id integer NOT NULL,
    metodo_pag_utente integer NOT NULL,
    provider character varying NOT NULL,
    numero_carta character(16) NOT NULL,
    data_scadenza date NOT NULL,
    cvv character(3) NOT NULL
);


ALTER TABLE public.metodo_pagamento OWNER TO postgres;

--
-- Name: metodo_pagamento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.metodo_pagamento_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.metodo_pagamento_id_seq OWNER TO postgres;

--
-- Name: metodo_pagamento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.metodo_pagamento_id_seq OWNED BY public.metodo_pagamento.id;


--
-- Name: metodo_pagamento_metodo_pag_utente_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.metodo_pagamento_metodo_pag_utente_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.metodo_pagamento_metodo_pag_utente_seq OWNER TO postgres;

--
-- Name: metodo_pagamento_metodo_pag_utente_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.metodo_pagamento_metodo_pag_utente_seq OWNED BY public.metodo_pagamento.metodo_pag_utente;


--
-- Name: mipiace; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mipiace (
    mipiace_utente integer NOT NULL,
    mipiace_vino integer NOT NULL
);


ALTER TABLE public.mipiace OWNER TO postgres;

--
-- Name: ordine; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ordine (
    id integer NOT NULL,
    ordine_utente integer NOT NULL,
    ordine_carrello integer NOT NULL,
    ordine_metodo_pag integer NOT NULL,
    ordine_indirizzo integer NOT NULL,
    data date NOT NULL,
    totale numeric NOT NULL,
    status character varying NOT NULL,
    ordine_promozione integer NOT NULL
);


ALTER TABLE public.ordine OWNER TO postgres;

--
-- Name: ordine_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ordine_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ordine_id_seq OWNER TO postgres;

--
-- Name: ordine_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ordine_id_seq OWNED BY public.ordine.id;


--
-- Name: ordine_ordine_carrello_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ordine_ordine_carrello_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ordine_ordine_carrello_seq OWNER TO postgres;

--
-- Name: ordine_ordine_carrello_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ordine_ordine_carrello_seq OWNED BY public.ordine.ordine_carrello;


--
-- Name: ordine_ordine_indirizzo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ordine_ordine_indirizzo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ordine_ordine_indirizzo_seq OWNER TO postgres;

--
-- Name: ordine_ordine_indirizzo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ordine_ordine_indirizzo_seq OWNED BY public.ordine.ordine_indirizzo;


--
-- Name: ordine_ordine_metodo_pag_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ordine_ordine_metodo_pag_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ordine_ordine_metodo_pag_seq OWNER TO postgres;

--
-- Name: ordine_ordine_metodo_pag_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ordine_ordine_metodo_pag_seq OWNED BY public.ordine.ordine_metodo_pag;


--
-- Name: ordine_ordine_promozione_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ordine_ordine_promozione_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ordine_ordine_promozione_seq OWNER TO postgres;

--
-- Name: ordine_ordine_promozione_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ordine_ordine_promozione_seq OWNED BY public.ordine.ordine_promozione;


--
-- Name: ordine_ordine_utente_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ordine_ordine_utente_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ordine_ordine_utente_seq OWNER TO postgres;

--
-- Name: ordine_ordine_utente_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ordine_ordine_utente_seq OWNED BY public.ordine.ordine_utente;


--
-- Name: promozione; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promozione (
    id integer NOT NULL,
    descrizione character varying NOT NULL,
    sconto_prezzo numeric,
    sconto_percentuale integer
);


ALTER TABLE public.promozione OWNER TO postgres;

--
-- Name: promozione_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.promozione_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.promozione_id_seq OWNER TO postgres;

--
-- Name: promozione_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.promozione_id_seq OWNED BY public.promozione.id;


--
-- Name: recensione; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recensione (
    id integer NOT NULL,
    descrizione text NOT NULL,
    recensione_sommelier integer NOT NULL,
    recensione_vino integer NOT NULL,
    data date NOT NULL
);


ALTER TABLE public.recensione OWNER TO postgres;

--
-- Name: recensione_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recensione_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recensione_id_seq OWNER TO postgres;

--
-- Name: recensione_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recensione_id_seq OWNED BY public.recensione.id;


--
-- Name: recensione_recensione_sommelier_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recensione_recensione_sommelier_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recensione_recensione_sommelier_seq OWNER TO postgres;

--
-- Name: recensione_recensione_sommelier_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recensione_recensione_sommelier_seq OWNED BY public.recensione.recensione_sommelier;


--
-- Name: recensione_recensione_vino_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recensione_recensione_vino_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recensione_recensione_vino_seq OWNER TO postgres;

--
-- Name: recensione_recensione_vino_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recensione_recensione_vino_seq OWNED BY public.recensione.recensione_vino;


--
-- Name: utente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.utente (
    id integer NOT NULL,
    nome character(1) NOT NULL,
    cognome character(1) NOT NULL,
    data_di_nascita date NOT NULL,
    email character(1) NOT NULL,
    password character(1) NOT NULL,
    numero_telefono character(10) NOT NULL,
    ruolo character(1) NOT NULL,
    utente_indirizzo integer NOT NULL
);


ALTER TABLE public.utente OWNER TO postgres;

--
-- Name: utente_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.utente_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.utente_id_seq OWNER TO postgres;

--
-- Name: utente_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.utente_id_seq OWNED BY public.utente.id;


--
-- Name: utente_utente_indirizzo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.utente_utente_indirizzo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.utente_utente_indirizzo_seq OWNER TO postgres;

--
-- Name: utente_utente_indirizzo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.utente_utente_indirizzo_seq OWNED BY public.utente.utente_indirizzo;


--
-- Name: vino; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vino (
    id integer NOT NULL,
    nome character varying NOT NULL,
    annata integer NOT NULL,
    prezzo numeric NOT NULL,
    gradazione_alcolica integer NOT NULL,
    vino_cantina integer NOT NULL,
    tipologia character varying NOT NULL,
    foto bytea NOT NULL,
    premi text NOT NULL
);


ALTER TABLE public.vino OWNER TO postgres;

--
-- Name: vino_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vino_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vino_id_seq OWNER TO postgres;

--
-- Name: vino_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vino_id_seq OWNED BY public.vino.id;


--
-- Name: vino_vino_cantina_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vino_vino_cantina_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vino_vino_cantina_seq OWNER TO postgres;

--
-- Name: vino_vino_cantina_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vino_vino_cantina_seq OWNED BY public.vino.vino_cantina;


--
-- Name: cantina id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cantina ALTER COLUMN id SET DEFAULT nextval('public.cantina_id_seq'::regclass);


--
-- Name: cantina cantina_indirizzo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cantina ALTER COLUMN cantina_indirizzo SET DEFAULT nextval('public.cantina_cantina_indirizzo_seq'::regclass);


--
-- Name: carrello id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carrello ALTER COLUMN id SET DEFAULT nextval('public.carrello_id_seq'::regclass);


--
-- Name: carrello carrello_vino; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carrello ALTER COLUMN carrello_vino SET DEFAULT nextval('public.carrello_carrello_vino_seq'::regclass);


--
-- Name: carrello carrello_utente; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carrello ALTER COLUMN carrello_utente SET DEFAULT nextval('public.carrello_carrello_utente_seq'::regclass);


--
-- Name: indirizzo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.indirizzo ALTER COLUMN id SET DEFAULT nextval('public.indirizzo_id_seq'::regclass);


--
-- Name: metodo_pagamento id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.metodo_pagamento ALTER COLUMN id SET DEFAULT nextval('public.metodo_pagamento_id_seq'::regclass);


--
-- Name: metodo_pagamento metodo_pag_utente; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.metodo_pagamento ALTER COLUMN metodo_pag_utente SET DEFAULT nextval('public.metodo_pagamento_metodo_pag_utente_seq'::regclass);


--
-- Name: ordine id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordine ALTER COLUMN id SET DEFAULT nextval('public.ordine_id_seq'::regclass);


--
-- Name: ordine ordine_utente; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordine ALTER COLUMN ordine_utente SET DEFAULT nextval('public.ordine_ordine_utente_seq'::regclass);


--
-- Name: ordine ordine_carrello; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordine ALTER COLUMN ordine_carrello SET DEFAULT nextval('public.ordine_ordine_carrello_seq'::regclass);


--
-- Name: ordine ordine_metodo_pag; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordine ALTER COLUMN ordine_metodo_pag SET DEFAULT nextval('public.ordine_ordine_metodo_pag_seq'::regclass);


--
-- Name: ordine ordine_indirizzo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordine ALTER COLUMN ordine_indirizzo SET DEFAULT nextval('public.ordine_ordine_indirizzo_seq'::regclass);


--
-- Name: ordine ordine_promozione; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordine ALTER COLUMN ordine_promozione SET DEFAULT nextval('public.ordine_ordine_promozione_seq'::regclass);


--
-- Name: promozione id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promozione ALTER COLUMN id SET DEFAULT nextval('public.promozione_id_seq'::regclass);


--
-- Name: recensione id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione ALTER COLUMN id SET DEFAULT nextval('public.recensione_id_seq'::regclass);


--
-- Name: recensione recensione_sommelier; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione ALTER COLUMN recensione_sommelier SET DEFAULT nextval('public.recensione_recensione_sommelier_seq'::regclass);


--
-- Name: recensione recensione_vino; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione ALTER COLUMN recensione_vino SET DEFAULT nextval('public.recensione_recensione_vino_seq'::regclass);


--
-- Name: utente id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utente ALTER COLUMN id SET DEFAULT nextval('public.utente_id_seq'::regclass);


--
-- Name: utente utente_indirizzo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utente ALTER COLUMN utente_indirizzo SET DEFAULT nextval('public.utente_utente_indirizzo_seq'::regclass);


--
-- Name: vino id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vino ALTER COLUMN id SET DEFAULT nextval('public.vino_id_seq'::regclass);


--
-- Name: vino vino_cantina; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vino ALTER COLUMN vino_cantina SET DEFAULT nextval('public.vino_vino_cantina_seq'::regclass);


--
-- Data for Name: cantina; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cantina (id, nome, cantina_indirizzo, descrizione) FROM stdin;
\.
COPY public.cantina (id, nome, cantina_indirizzo, descrizione) FROM '$$PATH$$/3437.dat';

--
-- Data for Name: carrello; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.carrello (id, carrello_vino, carrello_utente) FROM stdin;
\.
COPY public.carrello (id, carrello_vino, carrello_utente) FROM '$$PATH$$/3447.dat';

--
-- Data for Name: indirizzo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.indirizzo (id, via, numero_civico, citta, cap, regione, nazione) FROM stdin;
\.
COPY public.indirizzo (id, via, numero_civico, citta, cap, regione, nazione) FROM '$$PATH$$/3434.dat';

--
-- Data for Name: metodo_pagamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.metodo_pagamento (id, metodo_pag_utente, provider, numero_carta, data_scadenza, cvv) FROM stdin;
\.
COPY public.metodo_pagamento (id, metodo_pag_utente, provider, numero_carta, data_scadenza, cvv) FROM '$$PATH$$/3450.dat';

--
-- Data for Name: mipiace; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mipiace (mipiace_utente, mipiace_vino) FROM stdin;
\.
COPY public.mipiace (mipiace_utente, mipiace_vino) FROM '$$PATH$$/3462.dat';

--
-- Data for Name: ordine; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ordine (id, ordine_utente, ordine_carrello, ordine_metodo_pag, ordine_indirizzo, data, totale, status, ordine_promozione) FROM stdin;
\.
COPY public.ordine (id, ordine_utente, ordine_carrello, ordine_metodo_pag, ordine_indirizzo, data, totale, status, ordine_promozione) FROM '$$PATH$$/3456.dat';

--
-- Data for Name: promozione; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.promozione (id, descrizione, sconto_prezzo, sconto_percentuale) FROM stdin;
\.
COPY public.promozione (id, descrizione, sconto_prezzo, sconto_percentuale) FROM '$$PATH$$/3458.dat';

--
-- Data for Name: recensione; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recensione (id, descrizione, recensione_sommelier, recensione_vino, data) FROM stdin;
\.
COPY public.recensione (id, descrizione, recensione_sommelier, recensione_vino, data) FROM '$$PATH$$/3444.dat';

--
-- Data for Name: utente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.utente (id, nome, cognome, data_di_nascita, email, password, numero_telefono, ruolo, utente_indirizzo) FROM stdin;
\.
COPY public.utente (id, nome, cognome, data_di_nascita, email, password, numero_telefono, ruolo, utente_indirizzo) FROM '$$PATH$$/3432.dat';

--
-- Data for Name: vino; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vino (id, nome, annata, prezzo, gradazione_alcolica, vino_cantina, tipologia, foto, premi) FROM stdin;
\.
COPY public.vino (id, nome, annata, prezzo, gradazione_alcolica, vino_cantina, tipologia, foto, premi) FROM '$$PATH$$/3440.dat';

--
-- Name: cantina_cantina_indirizzo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cantina_cantina_indirizzo_seq', 1, false);


--
-- Name: cantina_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cantina_id_seq', 1, false);


--
-- Name: carrello_carrello_utente_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.carrello_carrello_utente_seq', 1, false);


--
-- Name: carrello_carrello_vino_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.carrello_carrello_vino_seq', 1, false);


--
-- Name: carrello_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.carrello_id_seq', 1, false);


--
-- Name: indirizzo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.indirizzo_id_seq', 1, false);


--
-- Name: metodo_pagamento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.metodo_pagamento_id_seq', 1, false);


--
-- Name: metodo_pagamento_metodo_pag_utente_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.metodo_pagamento_metodo_pag_utente_seq', 1, false);


--
-- Name: ordine_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ordine_id_seq', 1, false);


--
-- Name: ordine_ordine_carrello_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ordine_ordine_carrello_seq', 1, false);


--
-- Name: ordine_ordine_indirizzo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ordine_ordine_indirizzo_seq', 1, false);


--
-- Name: ordine_ordine_metodo_pag_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ordine_ordine_metodo_pag_seq', 1, false);


--
-- Name: ordine_ordine_promozione_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ordine_ordine_promozione_seq', 1, false);


--
-- Name: ordine_ordine_utente_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ordine_ordine_utente_seq', 1, false);


--
-- Name: promozione_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.promozione_id_seq', 1, false);


--
-- Name: recensione_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recensione_id_seq', 1, false);


--
-- Name: recensione_recensione_sommelier_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recensione_recensione_sommelier_seq', 1, false);


--
-- Name: recensione_recensione_vino_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recensione_recensione_vino_seq', 1, false);


--
-- Name: utente_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.utente_id_seq', 1, false);


--
-- Name: utente_utente_indirizzo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.utente_utente_indirizzo_seq', 1, false);


--
-- Name: vino_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vino_id_seq', 1, false);


--
-- Name: vino_vino_cantina_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vino_vino_cantina_seq', 1, false);


--
-- Name: cantina cantina_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cantina
    ADD CONSTRAINT cantina_pk PRIMARY KEY (id);


--
-- Name: carrello carrello_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carrello
    ADD CONSTRAINT carrello_pk PRIMARY KEY (id);


--
-- Name: indirizzo indirizzo_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.indirizzo
    ADD CONSTRAINT indirizzo_pk PRIMARY KEY (id);


--
-- Name: metodo_pagamento metodo_pagamento_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.metodo_pagamento
    ADD CONSTRAINT metodo_pagamento_pk PRIMARY KEY (id);


--
-- Name: mipiace mipiace_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mipiace
    ADD CONSTRAINT mipiace_pk PRIMARY KEY (mipiace_utente, mipiace_vino);


--
-- Name: ordine ordine_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordine
    ADD CONSTRAINT ordine_pk PRIMARY KEY (id);


--
-- Name: promozione promozione_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promozione
    ADD CONSTRAINT promozione_pk PRIMARY KEY (id);


--
-- Name: recensione recenzioni_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recenzioni_pk PRIMARY KEY (id);


--
-- Name: utente utente_emal_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utente
    ADD CONSTRAINT utente_emal_un UNIQUE (email);


--
-- Name: utente utente_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utente
    ADD CONSTRAINT utente_pk PRIMARY KEY (id);


--
-- Name: vino vino_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vino
    ADD CONSTRAINT vino_pk PRIMARY KEY (id);


--
-- Name: cantina cantina_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cantina
    ADD CONSTRAINT cantina_fk FOREIGN KEY (cantina_indirizzo) REFERENCES public.indirizzo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: carrello carrello_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carrello
    ADD CONSTRAINT carrello_fk FOREIGN KEY (carrello_utente) REFERENCES public.utente(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: carrello carrello_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carrello
    ADD CONSTRAINT carrello_fk_1 FOREIGN KEY (carrello_vino) REFERENCES public.vino(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: metodo_pagamento metodo_pagamento_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.metodo_pagamento
    ADD CONSTRAINT metodo_pagamento_fk FOREIGN KEY (metodo_pag_utente) REFERENCES public.utente(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: mipiace mipiace_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mipiace
    ADD CONSTRAINT mipiace_fk FOREIGN KEY (mipiace_utente) REFERENCES public.utente(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: mipiace mipiace_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mipiace
    ADD CONSTRAINT mipiace_fk_1 FOREIGN KEY (mipiace_vino) REFERENCES public.vino(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ordine ordine_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordine
    ADD CONSTRAINT ordine_fk FOREIGN KEY (ordine_metodo_pag) REFERENCES public.metodo_pagamento(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ordine ordine_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordine
    ADD CONSTRAINT ordine_fk_1 FOREIGN KEY (ordine_utente) REFERENCES public.utente(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ordine ordine_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordine
    ADD CONSTRAINT ordine_fk_2 FOREIGN KEY (ordine_carrello) REFERENCES public.carrello(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ordine ordine_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordine
    ADD CONSTRAINT ordine_fk_3 FOREIGN KEY (ordine_indirizzo) REFERENCES public.indirizzo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ordine ordine_fk_4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordine
    ADD CONSTRAINT ordine_fk_4 FOREIGN KEY (ordine_promozione) REFERENCES public.promozione(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: recensione recensione_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recensione_fk FOREIGN KEY (recensione_vino) REFERENCES public.vino(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: recensione recensione_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recensione_fk_1 FOREIGN KEY (recensione_sommelier) REFERENCES public.utente(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: utente utente_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utente
    ADD CONSTRAINT utente_fk FOREIGN KEY (utente_indirizzo) REFERENCES public.indirizzo(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vino vino_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vino
    ADD CONSTRAINT vino_fk FOREIGN KEY (vino_cantina) REFERENCES public.cantina(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

